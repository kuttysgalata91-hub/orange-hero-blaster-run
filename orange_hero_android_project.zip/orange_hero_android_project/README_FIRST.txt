ORANGE HERO: BLASTER RUN — FREE ANDROID APK BUILD
Developer/display name: Raghavan Maria

This project wraps the existing HTML game in a simple Android WebView app. It does not need Google Play or a paid developer account to build and share the APK.

EASIEST FREE BUILD METHOD (GitHub Actions):
1. On a computer or tablet browser, create/sign in to a GitHub account (a parent/guardian can help if needed).
2. Create a NEW PUBLIC repository named orange-hero-blaster-run.
3. Upload all files and folders from this project ZIP into the repository root. Make sure README_FIRST.txt, settings.gradle, build.gradle, app/ and .github/ are at the root.
4. Open the repository's Actions tab. Select “Build Orange Hero APK” and tap “Run workflow” (or wait for the first push build).
5. When the workflow finishes successfully, open that run and download the artifact named “Orange-Hero-Blaster-Run-APK”.
6. Extract the downloaded artifact ZIP to get app-debug.apk. Send that APK directly to friends/family.

INSTALLING:
On the receiving Android device, download the APK, open it, and allow installation from that source if Android asks. Only install APKs from someone you trust. Android menus vary by device.

IMPORTANT:
- The APK is a DEBUG build intended for personal sharing/testing, not Play Store publication.
- Keep the repository public if you want to use GitHub Actions without private-repository usage limits; do not upload passwords or private signing keys.
- The app requests no network permission and loads the bundled HTML game locally.
- Check the game on the target phone. If the HTML prototype has controls or layout issues on that device, the game itself may need adjustment.
- This project has not been built or tested on an Android device in this workspace.
